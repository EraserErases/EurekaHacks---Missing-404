import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Missing 404 - Edge Collision Counter")

# Load animation frames
try:
    frame1 = pygame.image.load("guy1.png").convert_alpha()
    frame2 = pygame.image.load("guy2.png").convert_alpha()
    death1 = pygame.image.load("death1.png").convert_alpha()
    death2 = pygame.image.load("death2.png").convert_alpha()
    cliffimage = pygame.image.load("cliff.png").convert_alpha()
    cliffimage = pygame.transform.scale(cliffimage, (WIDTH, HEIGHT))
except pygame.error as e:
    print(f"Could not load image: {e}")
    pygame.quit()
    sys.exit()

frames = [frame1, frame2]

# SOUND DISABLED
# pygame.mixer.init()
# try:
#     a1_music = pygame.mixer.Sound("A1 - It's just a burning memory.mp3")
#     siren = pygame.mixer.Sound("Police_siren.mp3")
#     heli = pygame.mixer.Sound("Helicopter.mp3")
# except pygame.error as e:
#     print(f"Could not load sounds: {e}")
#     pygame.quit()
#     sys.exit()

x, y = 100, 200
speed = 5
edge_count = 11
image_width, image_height = frame1.get_size()
current_color = 100
min_color = 20
color_step = 10
background_color = (current_color, current_color, current_color)
show_cliff = False

# Animation variables
frame_index = 0
animation_timer = 0
animation_speed = 10  # Lower = faster

# Endgame control
run_ending = False
ending_start_time = None
fact_display_started = False
fade_surface = pygame.Surface((WIDTH, HEIGHT))
fade_surface.fill((0, 0, 0))
fade_alpha = 0

# Facts
facts = [
    "Fact 1: Many Missing 411 cases occur in national parks with no official recordkeeping.",
    "Fact 2: Children are often found far from where they disappeared, sometimes across mountains.",
    "Fact 3: Some bodies are recovered in previously searched areas — days later.",
    "Fact 4: Survivors often report confusion, lost time, and strange sensations.",
    "Fact 5: Weather events frequently delay or obscure search efforts.",
    "Fact 6: David Paulides' research links dozens of strange unsolved disappearances.",
    "Fact 7: Animals and predators rarely account for these disappearances.",
    "Fact 8: Some cases involve sudden loss of scent for search dogs.",
    "Fact 9: A handful of children have been found alive but completely unaware of what happened.",
]

clock = pygame.time.Clock()
running = True

while running:
    dt = clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    moving = False

    if not run_ending:
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            x -= speed
            moving = True
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            x += speed
            moving = True

        # Animate always
        animation_timer += 1
        if animation_timer >= animation_speed:
            frame_index = (frame_index + 1) % len(frames)
            animation_timer = 0

        # Edge collision handling
        if edge_count < 12:
            if x < 0 or x + image_width > WIDTH:
                current_color = max(min_color, current_color - color_step)
                background_color = (current_color, current_color, current_color)
                edge_count += 1
                x, y = 100, 215
        else:
            show_cliff = True
            run_ending = True

    # Drawing
    if run_ending:
        current_time = pygame.time.get_ticks()
        if ending_start_time is None:
            ending_start_time = current_time
            # a1_music.play(-1)
            # siren.play()
            # heli.play()

        elapsed = (current_time - ending_start_time) / 1000  # seconds

        if elapsed <= 30:
            # Death animation
            if int(elapsed * 2) % 2 == 0:
                screen.blit(death1, (0, 0))
            else:
                screen.blit(death2, (0, 0))
        elif elapsed <= 120:
            if not fact_display_started:
                fact_display_started = True
                # siren.stop()
                # heli.stop()

            if fade_alpha < 255:
                fade_alpha += 5
            screen.fill((0, 0, 0))
            fade_surface.set_alpha(fade_alpha)
            screen.blit(fade_surface, (0, 0))

            fact_index = int((elapsed - 30) // 10)
            if fact_index < len(facts):
                font = pygame.font.SysFont("arial", 28)
                text = font.render(facts[fact_index], True, (255, 255, 255))
                text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
                screen.blit(text, text_rect)
        else:
            running = False

    elif show_cliff:
        screen.blit(cliffimage, (0, 0))
    else:
        screen.fill(background_color)
        screen.blit(frames[frame_index], (x, y))

    pygame.display.flip()

pygame.quit()
sys.exit()
